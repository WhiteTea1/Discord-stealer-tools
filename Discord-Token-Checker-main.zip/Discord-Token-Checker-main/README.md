# Discord-Token-Checker
Parse discord tokens from any file and directory. Check validity, nitro and paymenst.

Now it can parse tokens from any files and directory! I decided not to withdraw data from account. I don't want to complicate the checker!

## Menu
![cmd_mO9d4Vud3I](https://user-images.githubusercontent.com/49491499/130788540-a8d20eaa-751c-4bce-a586-f48cf4a9f6ae.png)
## Checker
![browser_G49q1xqgiV](https://user-images.githubusercontent.com/49491499/130812769-e5ab2ad3-612d-4d58-8bf9-d7b66b718a62.png)
## Parser
![cmd_ayxu9GSYTY](https://user-images.githubusercontent.com/49491499/130788608-2d4329d0-4571-4e26-8f79-cd7dda2046e1.png)


Disabling nitro checking on valid accounts increases speed by ~1.7 times

JS EDITION: https://github.com/amfero/DiscordTokenChecker 

TS EDITION: https://github.com/cattyngmd/DiscordTokenChecker-ts

PY EDITION: https://github.com/GuFFy12/Discord-Token-Checker
